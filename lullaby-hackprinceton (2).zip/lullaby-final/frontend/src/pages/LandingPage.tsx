import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

export default function LandingPage() {
  const navigate = useNavigate();
  const starsRef = useRef<HTMLDivElement>(null);
  const cursorRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const mxRef = useRef(0);
  const myRef = useRef(0);
  const rxRef = useRef(0);
  const ryRef = useRef(0);

  useEffect(() => {
    const container = starsRef.current;
    if (!container) return;
    for (let i = 0; i < 140; i++) {
      const s = document.createElement("div");
      const size = Math.random() * 2.5 + 0.5;
      s.style.cssText = `position:absolute;width:${size}px;height:${size}px;background:white;border-radius:50%;top:${Math.random()*100}%;left:${Math.random()*100}%;animation:ll-twinkle ${3+Math.random()*5}s ease-in-out infinite;animation-delay:${Math.random()*6}s;opacity:0;--op:${0.15+Math.random()*0.5};`;
      container.appendChild(s);
    }
  }, []);

  useEffect(() => {
    const onMove = (e: MouseEvent) => { mxRef.current = e.clientX; myRef.current = e.clientY; };
    document.addEventListener("mousemove", onMove);
    let raf: number;
    const tick = () => {
      if (cursorRef.current) { cursorRef.current.style.left = mxRef.current-4+"px"; cursorRef.current.style.top = myRef.current-4+"px"; }
      rxRef.current += (mxRef.current-rxRef.current-16)*0.1;
      ryRef.current += (myRef.current-ryRef.current-16)*0.1;
      if (ringRef.current) { ringRef.current.style.left = rxRef.current+"px"; ringRef.current.style.top = ryRef.current+"px"; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => { document.removeEventListener("mousemove", onMove); cancelAnimationFrame(raf); };
  }, []);

  useEffect(() => {
    const els = document.querySelectorAll(".ll-reveal");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e, i) => { if (e.isIntersecting) { setTimeout(() => e.target.classList.add("ll-visible"), i*90); obs.unobserve(e.target); } });
    }, { threshold: 0.12 });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <>
      <style>{CSS}</style>
      <div className="ll-cursor" ref={cursorRef} />
      <div className="ll-ring" ref={ringRef} />
      <div className="ll-stars" ref={starsRef} />
      <div className="ll-page">

        {/* HERO */}
        <section className="ll-hero">
          <div className="ll-moon-wrap"><div className="ll-moon" /></div>
          <p className="ll-eyebrow">HackPrinceton 2026</p>
          <h1 className="ll-title"><em>Lullaby</em></h1>
          <p className="ll-sub">Tell a story. Watch it become a film.</p>
          <button className="ll-btn" onClick={() => navigate("/picker")}
            onMouseEnter={() => ringRef.current?.classList.add("ll-ring-big")}
            onMouseLeave={() => ringRef.current?.classList.remove("ll-ring-big")}>
            <span className="ll-dot" /> Begin
          </button>
          <div className="ll-scroll-hint"><div className="ll-scroll-line" /></div>
        </section>

        {/* HOW IT WORKS */}
        <section className="ll-section ll-how">
          <div className="ll-container">
            <p className="ll-label ll-reveal">The Ritual</p>
            <h2 className="ll-h2 ll-reveal">Speak. We'll <em>handle</em><br />the rest.</h2>
            <div className="ll-steps">
              {[
                {n:"I",   title:"Set the scene",   desc:"Choose visual style, narrator voice, reading level, tone, and pacing. Sensible defaults are ready."},
                {n:"II",  title:"Tell your story",  desc:"Speak naturally. Pause. Wander. We transcribe, clean artifacts, and find the story inside your words."},
                {n:"III", title:"Watch it weave",   desc:"Your words transform on screen, character sketches bloom, scenes paint themselves in real time."},
                {n:"IV",  title:"Premiere",         desc:"A fully narrated illustrated film. AI voice, AI visuals, ambient sound — under 90 seconds."},
              ].map((s) => (
                <div className="ll-step ll-reveal" key={s.n}>
                  <div className="ll-step-num">{s.n}</div>
                  <div className="ll-step-title">{s.title}</div>
                  <div className="ll-step-desc">{s.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="ll-divider" />

        {/* QUOTE + STATS */}
        <section className="ll-quote-section">
          <p className="ll-big-quote ll-reveal">"A story doesn't have <em>one correct form</em>.<br />Lullaby makes that literal."</p>
          <p className="ll-quote-attr ll-reveal">Product Philosophy</p>
          <div className="ll-stat-row ll-reveal">
            <div className="ll-stat"><span className="ll-stat-num">2,160</span><span className="ll-stat-label">Unique film configurations<br />from one spoken story</span></div>
            <div className="ll-stat"><span className="ll-stat-num">&lt;90s</span><span className="ll-stat-label">From spoken words<br />to finished film</span></div>
            <div className="ll-stat"><span className="ll-stat-num">5</span><span className="ll-stat-label">Independent filter axes<br />you control</span></div>
          </div>
        </section>

        <div className="ll-divider" />

        {/* FILTER MATRIX */}
        <section className="ll-section">
          <div className="ll-container">
            <p className="ll-label ll-reveal">The Filter Matrix</p>
            <h2 className="ll-h2 ll-reveal">Same story.<br /><em>Infinite</em> films.</h2>
            <div className="ll-filters-grid ll-reveal">
              {[
                {axis:"Axis I",   name:"Visual Style",   count:"6",   pills:["Watercolor Storybook","Pixar / 3D","Studio Ghibli","Paper Cutout","Charcoal Sketch","Crayon Drawing"], active:0},
                {axis:"Axis II",  name:"Narrator Voice",  count:"6",   pills:["Warm Mother","Wise Grandfather","Playful Sister","Gentle Father","Mysterious Narrator","Kid Narrator"], active:0},
                {axis:"Axis III", name:"Reading Level",   count:"4",   pills:["Toddler (2–3)","Early Reader (4–6)","Grade School (7–10)","Advanced (11+)"], active:1},
                {axis:"Axis IV–V",name:"Tone & Pacing",   count:"5×3", pills:["Cozy","Adventurous","Whimsical","Mysterious","Tender","Unhurried","Natural","Brisk"], active:0},
              ].map((fc) => (
                <div className="ll-filter-card" key={fc.name}>
                  <div className="ll-filter-axis">{fc.axis}</div>
                  <div className="ll-filter-name">{fc.name}</div>
                  <div className="ll-filter-options">
                    {fc.pills.map((p,i) => <span key={p} className={`ll-pill${i===fc.active?" ll-pill-on":""}`}>{p}</span>)}
                  </div>
                  <span className="ll-filter-count">{fc.count}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FINAL CTA */}
        <section className="ll-final">
          <div className="ll-final-moon" />
          <p className="ll-final-title ll-reveal">Every story exists<br />in many simultaneous versions.</p>
          <button className="ll-btn ll-reveal" style={{animationDelay:"0.1s"}} onClick={() => navigate("/picker")}
            onMouseEnter={() => ringRef.current?.classList.add("ll-ring-big")}
            onMouseLeave={() => ringRef.current?.classList.remove("ll-ring-big")}>
            <span className="ll-dot" /> Tell yours
          </button>
        </section>

        <footer className="ll-footer">
          <span className="ll-footer-logo">Lullaby</span>
          <span>HackPrinceton 2026 — Entertainment & Media</span>
          <span>Built in 36 hours</span>
        </footer>
      </div>
    </>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=Instrument+Sans:wght@300;400&display=swap');
@keyframes ll-twinkle{0%,100%{opacity:0;transform:scale(.8)}50%{opacity:var(--op,.4);transform:scale(1)}}
@keyframes ll-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}
@keyframes ll-pulse{0%,100%{transform:scale(1);opacity:.4}50%{transform:scale(1.18);opacity:.9}}
@keyframes ll-up{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}
@keyframes ll-drip{0%{transform:scaleY(0);transform-origin:top;opacity:1}50%{transform:scaleY(1);transform-origin:top}51%{transform-origin:bottom}100%{transform:scaleY(0);transform-origin:bottom;opacity:0}}
body{cursor:none!important;margin:0;}
.ll-cursor{position:fixed;width:8px;height:8px;background:#c9a84c;border-radius:50%;pointer-events:none;z-index:9999;mix-blend-mode:screen;}
.ll-ring{position:fixed;width:34px;height:34px;border:1px solid rgba(201,168,76,.35);border-radius:50%;pointer-events:none;z-index:9998;transition:transform .3s ease;}
.ll-ring-big{transform:scale(1.7)!important;}
.ll-stars{position:fixed;inset:0;pointer-events:none;z-index:0;}
.ll-reveal{opacity:0;transform:translateY(30px);transition:opacity .8s ease,transform .8s ease;}
.ll-visible{opacity:1!important;transform:translateY(0)!important;}
.ll-page{font-family:'Instrument Sans',sans-serif;font-weight:300;background:linear-gradient(160deg,#0d1628 0%,#080d18 60%);color:#e8dfd0;min-height:100vh;overflow-x:hidden;}
.ll-hero{position:relative;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;z-index:1;}
.ll-moon-wrap{width:130px;height:130px;margin-bottom:3rem;animation:ll-float 6s ease-in-out infinite;}
.ll-moon{width:130px;height:130px;background:radial-gradient(circle at 36% 36%,#f5e8c8,#c9a84c 58%,#7a5a18);border-radius:50%;box-shadow:0 0 50px rgba(201,168,76,.3),0 0 140px rgba(100,130,220,.08),inset -20px -10px 0 rgba(0,0,0,.18);position:relative;}
.ll-moon::after{content:'';position:absolute;inset:-24px;border-radius:50%;background:radial-gradient(circle,rgba(201,168,76,.07) 0%,transparent 70%);animation:ll-pulse 4s ease-in-out infinite;}
.ll-eyebrow{font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:#c9a84c;margin-bottom:1.5rem;opacity:0;animation:ll-up 1s ease .3s forwards;}
.ll-title{font-family:'Cormorant Garamond',serif;font-size:clamp(4.5rem,13vw,10rem);font-weight:300;line-height:.9;letter-spacing:-.02em;color:#e8dfd0;margin:0 0 1.5rem;opacity:0;animation:ll-up 1s ease .5s forwards;}
.ll-title em{font-style:italic;color:#c9a84c;}
.ll-sub{font-family:'Cormorant Garamond',serif;font-size:clamp(1.1rem,2.5vw,1.5rem);font-style:italic;color:rgba(232,223,208,.5);max-width:480px;line-height:1.6;margin-bottom:3rem;opacity:0;animation:ll-up 1s ease .7s forwards;}
.ll-btn{display:inline-flex;align-items:center;gap:.75rem;padding:1rem 2.5rem;border:1px solid rgba(201,168,76,.45);border-radius:100px;font-family:'Instrument Sans',sans-serif;font-size:.82rem;letter-spacing:.14em;text-transform:uppercase;color:#e8dfd0;background:transparent;cursor:none;transition:all .4s ease;position:relative;overflow:hidden;opacity:0;animation:ll-up 1s ease .9s forwards;}
.ll-btn::before{content:'';position:absolute;inset:0;background:#c9a84c;transform:scaleX(0);transform-origin:left;transition:transform .4s ease;z-index:-1;}
.ll-btn:hover{color:#0d1628;border-color:#c9a84c;}
.ll-btn:hover::before{transform:scaleX(1);}
.ll-btn:hover .ll-dot{background:#0d1628;}
.ll-dot{width:6px;height:6px;background:#c9a84c;border-radius:50%;transition:background .4s;flex-shrink:0;}
.ll-scroll-hint{position:absolute;bottom:2.5rem;left:50%;transform:translateX(-50%);opacity:0;animation:ll-up 1s ease 1.5s forwards;}
.ll-scroll-line{width:1px;height:48px;background:linear-gradient(to bottom,rgba(201,168,76,.5),transparent);animation:ll-drip 2s ease-in-out infinite;}
.ll-section{position:relative;z-index:1;padding:8rem 2rem;}
.ll-container{max-width:1100px;margin:0 auto;}
.ll-label{font-size:.62rem;letter-spacing:.32em;text-transform:uppercase;color:#c9a84c;margin-bottom:1rem;}
.ll-h2{font-family:'Cormorant Garamond',serif;font-size:clamp(2.5rem,6vw,4.5rem);font-weight:300;line-height:1.05;color:#e8dfd0;margin-bottom:4rem;}
.ll-h2 em{font-style:italic;color:#c9a84c;}
.ll-how{background:linear-gradient(to bottom,transparent,rgba(26,39,68,.4),transparent);}
.ll-divider{height:1px;background:linear-gradient(to right,transparent,rgba(201,168,76,.18),transparent);margin:0 2rem;}
.ll-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));position:relative;}
.ll-steps::before{content:'';position:absolute;top:28px;left:8%;right:8%;height:1px;background:linear-gradient(to right,transparent,rgba(201,168,76,.25),transparent);}
.ll-step{padding:0 2rem 0 0;}
.ll-step-num{width:56px;height:56px;border:1px solid rgba(201,168,76,.35);border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:1.2rem;color:#c9a84c;margin-bottom:1.5rem;background:#080d18;position:relative;z-index:1;}
.ll-step-title{font-family:'Cormorant Garamond',serif;font-size:1.25rem;color:#e8dfd0;margin-bottom:.6rem;}
.ll-step-desc{font-size:.83rem;line-height:1.75;color:rgba(232,223,208,.42);}
.ll-quote-section{text-align:center;padding:7rem 2rem;}
.ll-big-quote{font-family:'Cormorant Garamond',serif;font-size:clamp(1.6rem,4vw,2.8rem);font-weight:300;font-style:italic;line-height:1.45;color:rgba(232,223,208,.68);max-width:820px;margin:0 auto 2rem;}
.ll-big-quote em{color:#c9a84c;font-style:normal;}
.ll-quote-attr{font-size:.68rem;letter-spacing:.22em;text-transform:uppercase;color:rgba(232,223,208,.2);}
.ll-stat-row{display:flex;gap:1px;background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.08);margin-top:6rem;}
.ll-stat{flex:1;padding:3rem 2rem;background:#0d1628;text-align:center;}
.ll-stat-num{font-family:'Cormorant Garamond',serif;font-size:clamp(2.5rem,6vw,4.5rem);font-weight:300;color:#c9a84c;line-height:1;display:block;margin-bottom:.75rem;}
.ll-stat-label{font-size:.68rem;letter-spacing:.14em;text-transform:uppercase;color:rgba(232,223,208,.32);}
.ll-filters-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.08);margin-top:4rem;}
.ll-filter-card{background:#0d1628;padding:2.5rem;position:relative;overflow:hidden;transition:background .4s;}
.ll-filter-card:hover{background:rgba(26,39,68,.7);}
.ll-filter-card::before{content:'';position:absolute;top:0;left:0;width:3px;height:0;background:#c9a84c;transition:height .4s ease;}
.ll-filter-card:hover::before{height:100%;}
.ll-filter-axis{font-size:.58rem;letter-spacing:.3em;text-transform:uppercase;color:#c9a84c;margin-bottom:.7rem;}
.ll-filter-name{font-family:'Cormorant Garamond',serif;font-size:1.75rem;font-weight:300;color:#e8dfd0;margin-bottom:1rem;}
.ll-filter-options{display:flex;flex-wrap:wrap;gap:.45rem;}
.ll-pill{font-size:.7rem;padding:.28rem .7rem;border:1px solid rgba(232,223,208,.1);border-radius:100px;color:rgba(232,223,208,.4);letter-spacing:.04em;}
.ll-pill-on{border-color:rgba(201,168,76,.45)!important;color:#c9a84c!important;}
.ll-filter-count{position:absolute;bottom:1.8rem;right:2.2rem;font-family:'Cormorant Garamond',serif;font-size:3rem;font-weight:300;color:rgba(201,168,76,.06);line-height:1;}
.ll-final{text-align:center;padding:10rem 2rem;}
.ll-final-moon{width:180px;height:180px;background:radial-gradient(circle at 36% 36%,#f5e8c8,#c9a84c 58%,#7a5a18);border-radius:50%;box-shadow:0 0 80px rgba(201,168,76,.18),0 0 180px rgba(100,130,220,.06);margin:0 auto 4rem;animation:ll-float 6s ease-in-out infinite;}
.ll-final-title{font-family:'Cormorant Garamond',serif;font-size:clamp(2rem,5vw,3.5rem);font-weight:300;font-style:italic;color:rgba(232,223,208,.75);margin-bottom:3rem;}
.ll-footer{border-top:1px solid rgba(232,223,208,.05);padding:2.5rem;display:flex;justify-content:space-between;align-items:center;font-size:.7rem;color:rgba(232,223,208,.18);letter-spacing:.08em;position:relative;z-index:1;}
.ll-footer-logo{font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-weight:300;color:rgba(232,223,208,.35);}
@media(max-width:640px){.ll-steps{grid-template-columns:1fr 1fr;gap:2rem}.ll-steps::before{display:none}.ll-filters-grid{grid-template-columns:1fr}.ll-stat-row{flex-direction:column}.ll-footer{flex-direction:column;gap:1rem;text-align:center}}
`;
