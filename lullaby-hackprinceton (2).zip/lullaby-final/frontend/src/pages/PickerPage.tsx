import { useMemo, useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { FILTER_CONFIG, defaultFilters, getFilterLabel } from "../filters";
import type { StoryFilters } from "../types/job";

function FilterRow({ title, valueLabel, expanded, onToggle, children }: {
  title: string; valueLabel: string; expanded: boolean; onToggle: () => void; children: ReactNode;
}) {
  return (
    <div style={{borderRadius:16,border:"1px solid rgba(201,168,76,.15)",background:"rgba(13,22,40,.7)",overflow:"hidden",transition:"border-color .3s"}}
      onMouseEnter={e=>(e.currentTarget.style.borderColor="rgba(201,168,76,.35)")}
      onMouseLeave={e=>(e.currentTarget.style.borderColor="rgba(201,168,76,.15)")}>
      <button type="button" onClick={onToggle} style={{width:"100%",textAlign:"left",padding:"1.25rem 1.5rem",display:"flex",alignItems:"center",justifyContent:"space-between",gap:"1rem",background:"none",border:"none",cursor:"none",color:"inherit"}}>
        <div>
          <p style={{fontSize:".6rem",letterSpacing:".28em",textTransform:"uppercase",color:"#c9a84c",marginBottom:".3rem",fontFamily:"'Instrument Sans',sans-serif"}}>{title}</p>
          <p style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.25rem",color:"#e8dfd0"}}>{valueLabel}</p>
        </div>
        <span style={{fontSize:".68rem",letterSpacing:".12em",textTransform:"uppercase",color:"rgba(232,223,208,.35)",fontFamily:"'Instrument Sans',sans-serif",flexShrink:0}}>{expanded?"Hide":"Change"}</span>
      </button>
      {expanded && <div style={{padding:"0 1.5rem 1.5rem"}}>{children}</div>}
    </div>
  );
}

export default function PickerPage() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState<StoryFilters>(defaultFilters);
  const [openAxis, setOpenAxis] = useState<keyof StoryFilters | null>("visualStyle");

  const summary = useMemo(() =>
    `${getFilterLabel("visualStyle",filters.visualStyle)} · ${getFilterLabel("narratorVoice",filters.narratorVoice)} · ${getFilterLabel("readingLevel",filters.readingLevel)} · ${getFilterLabel("tone",filters.tone)} · ${getFilterLabel("pacing",filters.pacing)}`,
    [filters]
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=Instrument+Sans:wght@300;400&display=swap');
        body{cursor:none!important;margin:0;}
        .pk-cursor{position:fixed;width:8px;height:8px;background:#c9a84c;border-radius:50%;pointer-events:none;z-index:9999;mix-blend-mode:screen;}
        .pk-ring{position:fixed;width:34px;height:34px;border:1px solid rgba(201,168,76,.35);border-radius:50%;pointer-events:none;z-index:9998;}
        .pk-opt{border-radius:12px;padding:.75rem 1rem;text-align:left;border:1px solid rgba(232,223,208,.1);background:rgba(8,13,24,.6);color:rgba(232,223,208,.65);font-family:'Instrument Sans',sans-serif;font-size:.85rem;cursor:none;transition:all .25s ease;width:100%;}
        .pk-opt:hover{border-color:rgba(201,168,76,.3);color:#e8dfd0;}
        .pk-opt-on{border-color:rgba(201,168,76,.6)!important;background:rgba(201,168,76,.1)!important;color:#e8dfd0!important;}
        .pk-btn{display:inline-flex;align-items:center;gap:.75rem;padding:.85rem 2rem;border:1px solid rgba(201,168,76,.45);border-radius:100px;font-family:'Instrument Sans',sans-serif;font-size:.8rem;letter-spacing:.12em;text-transform:uppercase;color:#e8dfd0;background:transparent;cursor:none;transition:all .35s ease;position:relative;overflow:hidden;}
        .pk-btn::before{content:'';position:absolute;inset:0;background:#c9a84c;transform:scaleX(0);transform-origin:left;transition:transform .35s ease;z-index:-1;}
        .pk-btn:hover{color:#0d1628;border-color:#c9a84c;}
        .pk-btn:hover::before{transform:scaleX(1);}
        .pk-btn-ghost{background:none;border:1px solid rgba(232,223,208,.12);color:rgba(232,223,208,.45);border-radius:100px;padding:.85rem 2rem;font-family:'Instrument Sans',sans-serif;font-size:.8rem;letter-spacing:.12em;text-transform:uppercase;cursor:none;transition:all .3s ease;}
        .pk-btn-ghost:hover{border-color:rgba(232,223,208,.3);color:rgba(232,223,208,.8);}
        .pk-dot{width:6px;height:6px;background:#c9a84c;border-radius:50%;flex-shrink:0;transition:background .35s;}
        .pk-btn:hover .pk-dot{background:#0d1628;}
      `}</style>

      <div className="pk-cursor" id="pkcursor" />
      <div className="pk-ring" id="pkring" />

      <script dangerouslySetInnerHTML={{__html:`
        (function(){
          var mx=0,my=0,rx=0,ry=0;
          document.addEventListener('mousemove',function(e){mx=e.clientX;my=e.clientY;});
          (function tick(){
            var c=document.getElementById('pkcursor'),r=document.getElementById('pkring');
            if(c){c.style.left=mx-4+'px';c.style.top=my-4+'px';}
            rx+=(mx-rx-16)*0.1;ry+=(my-ry-16)*0.1;
            if(r){r.style.left=rx+'px';r.style.top=ry+'px';}
            requestAnimationFrame(tick);
          })();
        })();
      `}} />

      <div style={{fontFamily:"'Instrument Sans',sans-serif",fontWeight:300,background:"linear-gradient(160deg,#0d1628 0%,#080d18 60%)",color:"#e8dfd0",minHeight:"100vh",padding:"3rem 1.5rem"}}>
        <div style={{maxWidth:720,margin:"0 auto"}}>

          {/* Back */}
          <button type="button" onClick={() => navigate("/")} style={{background:"none",border:"none",color:"rgba(232,223,208,.35)",fontSize:".68rem",letterSpacing:".2em",textTransform:"uppercase",cursor:"none",marginBottom:"3rem",display:"flex",alignItems:"center",gap:".5rem",fontFamily:"'Instrument Sans',sans-serif"}}>
            ← Back
          </button>

          {/* Header */}
          <div style={{marginBottom:"3rem"}}>
            <p style={{fontSize:".62rem",letterSpacing:".32em",textTransform:"uppercase",color:"#c9a84c",marginBottom:".75rem"}}>Step 1 of 2</p>
            <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"clamp(2.5rem,7vw,4rem)",fontWeight:300,color:"#e8dfd0",margin:"0 0 .75rem",lineHeight:1.05}}>
              Choose your <em style={{fontStyle:"italic",color:"#c9a84c"}}>version</em>
            </h1>
            <p style={{fontSize:".85rem",color:"rgba(232,223,208,.4)",lineHeight:1.6}}>
              Pick one value per axis. Defaults are set — continue immediately or customise.
            </p>
          </div>

          {/* Filter rows */}
          <div style={{display:"flex",flexDirection:"column",gap:"1rem",marginBottom:"2.5rem"}}>
            {FILTER_CONFIG.map((axis) => (
              <FilterRow
                key={axis.key}
                title={axis.title}
                valueLabel={getFilterLabel(axis.key, filters[axis.key])}
                expanded={openAxis === axis.key}
                onToggle={() => setOpenAxis(prev => prev === axis.key ? null : axis.key)}
              >
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:".5rem"}}>
                  {axis.options.map((option) => {
                    const selected = filters[axis.key] === option.value;
                    return (
                      <button key={option.value} type="button"
                        className={`pk-opt${selected?" pk-opt-on":""}`}
                        onClick={() => setFilters(prev => ({...prev,[axis.key]:option.value}))}>
                        <div>{option.label}</div>
                        {option.subtitle && <div style={{fontSize:".72rem",opacity:.6,marginTop:".2rem"}}>{option.subtitle}</div>}
                      </button>
                    );
                  })}
                </div>
              </FilterRow>
            ))}
          </div>

          {/* Config summary */}
          <div style={{borderRadius:16,border:"1px solid rgba(201,168,76,.12)",background:"rgba(201,168,76,.04)",padding:"1.25rem 1.5rem",marginBottom:"2.5rem"}}>
            <p style={{fontSize:".58rem",letterSpacing:".28em",textTransform:"uppercase",color:"#c9a84c",marginBottom:".6rem"}}>Current Configuration</p>
            <p style={{fontSize:".85rem",color:"rgba(232,223,208,.7)",lineHeight:1.7,fontFamily:"'Cormorant Garamond',serif",fontStyle:"italic"}}>{summary}</p>
          </div>

          {/* Actions */}
          <div style={{display:"flex",flexWrap:"wrap",gap:"1rem",alignItems:"center"}}>
            <button type="button" className="pk-btn-ghost" onClick={() => setFilters(defaultFilters)}>
              Reset defaults
            </button>
            <button type="button" className="pk-btn" onClick={() => navigate("/record", {state:{filters}})}>
              <span className="pk-dot" />
              Continue to Record
            </button>
          </div>

        </div>
      </div>
    </>
  );
}
